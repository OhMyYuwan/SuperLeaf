![YuwanLabWriter banner](assets/github-header-banner.png)

# Welcome to YuwanLabWriter

YuwanLabWriter is a local-first research writing workspace built for drafting,
reviewing, and polishing academic documents with native Agent support.

## Start Here

- Use `main.tex` for a LaTeX-first manuscript.
- Use this `main.md` file for notes, planning, or Markdown-first drafts.
- Put images and other project assets in the `assets` folder.
- Invite Agents into the discussion and workflow panels when you want review,
  critique, or rewriting help.

## A Good First Outline

1. Problem and motivation
2. Related work
3. Method or system design
4. Experiments or evaluation
5. Results, limitations, and next steps

Replace this starter document with your own project brief whenever you are
ready.
